#' ---
#' title: UK gas consumption over time
#' author: Sadiq M.
#' date: Spring term 2025
#' ---

# 1. R Scratchpad ------------------------------------------------------------
?co2 #seeing description of co2 data
library(help = "datasets") #checking all the possible data sets to choose
#Loading all the libraries I need
library(prophet)
library(ggplot2) #possible plotting
library(knitr) 
library(dplyr) #using this to rename date to ds for prophet 
library(zoo)

#I have chosen to use the UKgas data 
?UKgas #UK gas consumption over quarters 1960 - 1986 [108 data points length] (in million of therms)
is.ts(UKgas) #[TRUE], it is already in time series format
plot(UKgas)

date = zoo::as.yearqtr(time(UKgas)) #formatting for future prophet
y = as.numeric(UKgas)
ukgas_df <- data.frame(date, y)

?plot()
?ggplot2() #for plots and stuff
plot(ukgas_df, type="o", col="black", main="UK Quartely Gas Consumption", xlab="Year", ylab="Therms (in millions)")
summary(ukgas_df) #getting info about UKgas data set 
summary(ukgas_df$y)
sd(ukgas_df$y)

#setting up Prophet
prophet_df <- ukgas_df %>% rename(ds = date, y = y) #rename date for prophet format
prophet_m <- prophet(prophet_df)
prophet_future <- make_future_dataframe(prophet_m, periods = 8, freq = "quarter")
prophet_prediction <- predict(prophet_m, prophet_future)
1163.9-84.8 #range

